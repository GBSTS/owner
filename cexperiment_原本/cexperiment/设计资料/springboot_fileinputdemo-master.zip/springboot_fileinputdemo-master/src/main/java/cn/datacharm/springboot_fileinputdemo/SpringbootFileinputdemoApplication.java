package cn.datacharm.springboot_fileinputdemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication

public class SpringbootFileinputdemoApplication {

    public static void main(String[] args) {
        SpringApplication.run(SpringbootFileinputdemoApplication.class, args);
    }

}
