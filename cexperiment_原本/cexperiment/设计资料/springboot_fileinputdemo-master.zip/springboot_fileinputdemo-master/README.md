# springboot_fileinputdemo
springboot+bootstrap fileinput插件实现多文件上传及显示本地图片

重写WebMvcConfigurer下addResourceHandlers改变资源访问路径
-> Windows下图片会上传到 G:/img 目录下

![image](https://github.com/feihb123/images/blob/master/fileinput.png)
