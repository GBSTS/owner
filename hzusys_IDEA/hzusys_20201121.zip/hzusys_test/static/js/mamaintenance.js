$(document).ready(function() {
	// $.ajax({//需要服务器的支持
	// 	url: "/getMaintainData",
	// 	success: function(result) {//result中包含vm_left,vm_right的json数据
	// 		eval(result)
	// 	}
	// });

	layui.use('element', function() {
		var element = layui.element;

	});

	var vm_left = new Vue({
		el: "#leftFrame",
		data: {
			applyAintList: [{
				applyId: '0004',
				applyContent: ['维护内容1', '维护内容2', '维护内容3', '维护内容4', '维护内容5']
			}, {
				applyId: '0005',
				applyContent: ['维护内容1', '维护内容2', '维护内容3', '维护内容4']
			}, {
				applyId: '0006',
				applyContent: ['维护内容1', '维护内容2', '维护内容3', '维护内容4', '维护内容5']
			}, {
				applyId: '0007',
				applyContent: ['维护内容1', '维护内容2', '维护内容3', '维护内容4', '维护内容5']
			}],
			historyAintList: [{
				applyId: '0001',
				applyContent: ['维护内容1', '维护内容2', '维护内容3', '维护内容4', '维护内容5'],
				dealContent: ['处理处理处理处理处理处理处理处理处理处理1', 'hello hello hello hello hello hello hello hello hello hello .', '处理3',
					'处理4', '处理5'
				]
			}, {
				applyId: '0002',
				applyContent: ['维护内容1', '维护内容2', '维护内容3', '维护内容4'],
				dealContent: ['处理处理处理处理处理处理处理处理处理处理1', 'hello hello hello hello hello hello hello hello hello hello .', '处理3',
					'处理4'
				]
			}, {
				applyId: '0003',
				applyContent: ['维护内容1', '维护内容2', '维护内容3', '维护内容4', '维护内容5', '维护内容2', '维护内容3', '维护内容4', '维护内容5'],
				dealContent: ['处理处理处理处理处理处理处理处理处理处理1', 'hello hello hello hello hello hello hello hello hello hello .', '处理3',
					'处理4', '处理5', 'hello hello hello hello hello hello hello hello hello hello .', '处理3', '处理4', '处理5'
				]
			}]
		},
		methods: {
			openApplyPage: function(item) {
				data = vm_right.$data;
				data.isDeal = true;
				data.maintenanceId = item.applyId;
				data.maintenanceContent = item.applyContent;
				data.dealAccordingly = '';
			},
			openHistoryPage: function(item) {
				data = vm_right.$data;
				data.isDeal = false;
				data.maintenanceId = item.applyId;
				data.maintenanceContent = item.applyContent;
				data.dealAccordingly = item.dealContent;
			}
		}
	});

	var vm_right = new Vue({
		el: "#rightFrame",
		data: {
			maintenanceId: '0001',
			isDeal: true, //查看历史维护情况才false
			maintenanceContent: ['维护内容1', '维护内容2', '维护内容3', '维护内容4', '维护内容5'],
			dealAccordingly: ''
		},
		methods: {
			receivingMaintenance: function(maintenanceId) {
				alert("维护编号：" + maintenanceId);
				/**
				 * 向服务器发送接收维护信息
				 */
			},
			dealMaintenance: function(maintenanceId) {
				alert("维护处理编号：" + maintenanceId);
				/**
				 * 向服务器发送维护处理信息
				 */
			}
		}
	})

});
