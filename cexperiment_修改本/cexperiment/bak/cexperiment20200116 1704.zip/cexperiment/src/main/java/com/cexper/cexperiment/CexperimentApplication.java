package com.cexper.cexperiment;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CexperimentApplication {

	public static void main(String[] args) {
		SpringApplication.run(CexperimentApplication.class, args);
	}

}
