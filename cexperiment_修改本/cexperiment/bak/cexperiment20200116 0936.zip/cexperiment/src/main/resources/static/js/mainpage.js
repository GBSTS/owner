ourclass.onclick=function(){
	alert("点击了我们班，引发了事件！");	
}

ourstudy.addEventListener("click",function(){
	alert("点击了去上课，引发了事件！");		
	},false);
	
function myhomework(){
	alert("点击了做作业，引发了事件！");
}