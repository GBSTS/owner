package com.cexper.cexperiment.service;

import com.cexper.cexperiment.model.Cexperimentnode;

public interface CexperimentnodeService {

    //根据ID查询实验手册表记录
    public Cexperimentnode findCexperimentnodeById(int id);


}
