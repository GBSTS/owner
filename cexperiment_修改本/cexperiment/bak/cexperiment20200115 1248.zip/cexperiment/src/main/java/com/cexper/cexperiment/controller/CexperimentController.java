package com.cexper.cexperiment.controller;

import com.cexper.cexperiment.model.Cexperimentnode;
import com.cexper.cexperiment.service.CexperimentnodeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;

@RestController
public class CexperimentController {


    @Resource
    private CexperimentnodeService cexperimentnodeService;


    @RequestMapping("getcexpnode")
    public String getcexpermentnode(int id){
        String retStr="";

        Cexperimentnode cen=cexperimentnodeService.findCexperimentnodeById(id);
        if(cen !=null){
            retStr=cen.getCename();
        }

        return retStr;
    }



}
