package com.cexper.cexperiment.service;

import com.cexper.cexperiment.model.Cexperimentnode;

public interface CexperimentnodeService {

    public Cexperimentnode findCexperimentnodeById(int id);


}
